import kareltherobot.*;
import java.awt.event.*;
import kareltherobot.Robot;
import java.awt.*;

public class Player extends Robot implements KeyListener  {
    
    /**
      Constructor for player, takes a Color parameter to add color to the robot
    */
    public Player ( int s, int a, Direction d, int b, Color color )  {
        super ( s, a, d, b, color ) ;
    }
    
    /**
        Reset method that moves the player robot back to the beginning after reaching the end
    */
    public void reset ( ) {
        // setting the world delay really low so that it happens really fast and is not seen
        World.setDelay (0);
        turnLeft();
        turnLeft();
        while ( frontIsClear() ) {
            move();
        }
        turnLeft();
        turnLeft();
        World.setDelay ( 30 ) ;  // resetting world delay     
    }
        
    /**
      Method moves the robot forward when the up arrow is pressed
    */
    public void keyPressed(KeyEvent e) {
        // moves the robot forward if user clicks the up key and the front is still clear
        if ( e.getKeyCode() == KeyEvent.VK_UP && frontIsClear() && !nextToARobot( ) )  {
            move();
        }   
    }
    public void keyReleased(KeyEvent e) { }
    public void keyTyped(KeyEvent e) {}
}
