import kareltherobot.World;
import java.awt.*;
import kareltherobot.World;
import kareltherobot.*;
import java.awt.event.*;
import kareltherobot.Robot;

public class ScoreKeeper extends Robot implements Directions  {
    
    /**
      Scorekeeper constructor, doesn't have Color parameter like the others because it will be invisible
    */
    public ScoreKeeper ( int s, int a, Direction d, int b )  {
        super ( s, a, d, b ) ;
    }
}