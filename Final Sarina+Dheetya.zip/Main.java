import kareltherobot.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.event.KeyListener;
import kareltherobot.Robot;
import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.Clip;
import javax.sound.sampled.SourceDataLine;


public class Main extends IOException implements Directions {

    public static void main ( String[] args )   {
    
        // setting World characterisitcs
       World.setDelay ( 30 ) ;
       World.setVisible ( true ) ;
       World.setWorldColor ( Color.BLACK ) ; 
       World.setStreetColor ( Color.BLACK ) ;
       World.setNeutroniumColor ( Color.RED ) ;
              
       // building walls 
       World.placeEWWall ( 9, 1, 9 ) ;       
       World.placeNSWall ( 1, 9, 9 ) ;

        // crosserSpeed is increased as the player gets more points to make it harder
       int crosserSpeed = 40;
       World.setDelay ( crosserSpeed ) ;
   
        // creating the different robots in the world
        World.setDelay (0);
        Player p = new Player ( 1, 5, North, 3, Color.RED ) ;
        ScoreKeeper score = new ScoreKeeper ( 1, 4, East, infinity ) ;
        score.setVisible ( false ) ; // making the score keeper invisible to just see the beepers
        SpaceCrosser crosser1 = new SpaceCrosser ( 7, 5, East, 0, Color.BLUE ) ;
        SpaceCrosser crosser2 = new SpaceCrosser ( 5, 8, West, 0, Color.BLUE ) ;
        SpaceCrosser crosser3 = new SpaceCrosser ( 8, 1, East, 0, Color.BLUE ) ;
        SpaceCrosser crosser4 = new SpaceCrosser ( 3, 4, West, 0, Color.BLUE ) ;
        SpaceCrosser crosser5 = new SpaceCrosser ( 4, 6, East, 0, Color.BLUE ) ;
        SpaceCrosser crosser6 = new SpaceCrosser ( 6, 3, West, 0, Color.BLUE ) ;
        World.setDelay ( crosserSpeed ) ;

        // creating EasySound objects
        EasySound cheering = new EasySound ( "/Users/sarinapatel/Downloads/cheering.wav" );
        EasySound boing = new EasySound ( "/Users/sarinapatel/Downloads/boing2.wav" );
  
        // adding key listener
        World.worldCanvas().addKeyListener( p ) ;
        World.showSpeedControl ( true ) ;

        // loops until the player loses ( hits a crosser )
        while ( true )  {

            // checking if player reached the end
            if ( !p.frontIsClear() ) {
                //ps.playCheer ( ) ;
                cheering.play ();
                p.reset(); // reseting position to start
                score.putBeeper(); // adding point to the score

                // speeding up crossers
                crosserSpeed -= 4 ; 
                World.setDelay ( crosserSpeed) ;
            }

            // checking if player collided with a crosser
            if ( p.nextToARobot() ) {
                //ps.playBoing ( ) ;
                boing.play ();
                World.stop ( ) ; // stops the world and crossers, game over
                //changing the state of the world when game is over
                World.setWorldColor ( Color.RED ) ;
                World.setStreetColor ( Color.RED ) ; 
                break;
            }
        }
    }
}