import kareltherobot.World;
import java.awt.*;
import kareltherobot.World;
import kareltherobot.*;
import java.awt.event.*;
import kareltherobot.Robot;

public class SpaceCrosser extends Robot implements Directions, Runnable  {
    
    /**
      SpaceCrosser constructor, sets up a thread for each new crosser created. Color parameter to set color of robot
    */
    public SpaceCrosser ( int s, int a, Direction d, int b, Color color )   {
        super ( s, a, d, b, color ) ;
        World.setupThread ( this ) ;
    }


    /**
        Move across method contiuosly moves the spacecrossers across the screen until the player collides with one of them
    */
    public void moveAcross ( )  {
        
        while ( frontIsClear()  )  { // detects the walls on the sides of the world
            move();
        }
        turnLeft();
        turnLeft();

        Thread t = new Thread ( this ) ;
        t.start();
    }  

    public void run ( )  {
        moveAcross ( ) ;
    }
}